﻿using System;
using System.Collections.Generic;
using demo.ViewModels;
using Xamarin.Forms;

namespace demo.Views
{
    public partial class AddItemPage : ContentPage
    {
        private AddItemPageViewModel viewModel
        {
            get
            {
                return (AddItemPageViewModel)BindingContext;
            }
        }

        public AddItemPage(string type)
        {
            InitializeComponent();
            viewModel.Page = this;
            viewModel.SetType(type);
        }
    }
}
