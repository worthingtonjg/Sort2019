﻿using System;
using System.Collections.Generic;
using demo.ViewModels;
using Xamarin.Forms;

namespace demo.Views
{
    public partial class MatchPage : ContentPage
    {
        private MatchPageViewModel viewModel
        {
            get
            {
                return (MatchPageViewModel)BindingContext;
            }
        }

        public MatchPage()
        {
            InitializeComponent();
            viewModel.Page = this;
        }
    }
}
