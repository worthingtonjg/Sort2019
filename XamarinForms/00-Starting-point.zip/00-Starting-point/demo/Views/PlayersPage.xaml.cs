﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using demo.ViewModels;
using Xamarin.Forms;

namespace demo.Views
{
    public partial class PlayersPage : ContentPage
    {
        private PlayersPageViewModel viewModel
        {
            get
            {
                return (PlayersPageViewModel)BindingContext;
            }
        }

        public PlayersPage()
        {
            InitializeComponent();
            viewModel.Page = this;
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();

            await viewModel.LoadAsync();
        }
    }
}
