﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace demo.Views
{
    public partial class StatsPage : ContentPage
    {
        public StatsPage()
        {
            InitializeComponent();
        }
    }
}
