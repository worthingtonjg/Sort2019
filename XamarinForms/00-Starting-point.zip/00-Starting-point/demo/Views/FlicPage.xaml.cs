﻿using System;
using System.Collections.Generic;
using demo.ViewModels;
using Xamarin.Forms;

namespace demo.Views
{
    public partial class FlicPage : ContentPage
    {
        private FlicPageViewModel viewModel
        {
            get
            {
                return (FlicPageViewModel)BindingContext;
            }
        }
        
        public FlicPage()
        {
            InitializeComponent();
            viewModel.Page = this;
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();

            await viewModel.LoadAsync();
        }
    }
}
