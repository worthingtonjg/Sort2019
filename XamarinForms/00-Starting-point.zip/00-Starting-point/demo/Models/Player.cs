﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo.Models
{
    public class Player
    {
        public Guid PlayerId { get; set; }

        public string Name { get; set; }

    }
}