﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo.Models
{
    public class Flic
    {
        public Guid FlicId { get; set; }

        public string Name { get; set; }
    }
}
