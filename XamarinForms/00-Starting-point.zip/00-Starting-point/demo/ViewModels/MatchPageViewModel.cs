﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using demo.Models;
using demo.Services;
using demo.ViewModels.ChildViewModels;
using Xamarin.Forms;

namespace demo.ViewModels
{
    public class MatchPageViewModel : BaseViewModel
    {
        public MatchPageViewModel()
        {
        }
    }
}
