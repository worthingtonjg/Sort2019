﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using demo.Models;
using demo.Services;
using demo.Views;
using Xamarin.Forms;

namespace demo.ViewModels
{
    public class FlicPageViewModel : BaseViewModel
    {
        public List<Flic> Flics { get; set; }

        public Command DeleteFlicCommand { get; set; }
        public Command AddFlicCommand { get; set; }

        public FlicPageViewModel()
        {
            DeleteFlicCommand = new Command((o) => DeleteFlic(o));
            AddFlicCommand = new Command(() => AddFlic());
            MessagingCenter.Subscribe<AddItemPageViewModel, string>(this, "DoSaveFlic", async (s, a) => await DoSaveFlic(s, a));

            if (DesignMode.IsDesignModeEnabled)
            {
                Flics = new List<Flic>()
                {
                    new Flic { Name = "Flic 1" },
                    new Flic { Name = "Flic 2" },
                    new Flic { Name = "Flic 3" },
                    new Flic { Name = "Flic 4" },
                };
            }
        }

        private async Task AddFlic()
        {
            await Navigation.PushAsync(new AddItemPage("Flic"));
        }

        private async Task DoSaveFlic(AddItemPageViewModel sender, string newFlicName)
        {
            await HttpHelper.Instance.PostAsync($"flics?name={newFlicName}", "");
            await Navigation.PopAsync();
        }

        private async Task DeleteFlic(object o)
        {
            Flic p = o as Flic;

            bool confirm = await Page.DisplayAlert("Confirm Delete", $"Delete Flic: {p.Name}", "Accept", "Cancel");
            if (!confirm) return;

            await HttpHelper.Instance.DeleteAsync($"flics/{p.FlicId}");
            await LoadAsync();
        }

        public async Task LoadAsync()
        {
            var flics = await HttpHelper.Instance.GetListAsync<Flic>("flics");
            SetValue(() => Flics, flics);
        }
    }
}
