﻿using System;
using Xamarin.Forms;

namespace demo.ViewModels
{
    public class AddItemPageViewModel : BaseViewModel
    {
        public string Type { get; set; }
        public string Name { get; set; }

        public Command SaveCommand { get; set; }

        public string NamePlaceholder
        {
            get { return $"New {Type} Name"; }
        }

        public AddItemPageViewModel()
        {
            SaveCommand = new Command(() => {
                // TODO: SEND MESSAGE TO DO THE SAVE
            });
        }

        public void SetType(string type)
        {
            SetValue(() => Type, type);
            OnPropertyChanged("NamePlaceholder");
        }
    }
}
