﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using demo.Models;
using demo.Services;
using demo.Views;
using Xamarin.Forms;

namespace demo.ViewModels
{
    public class PlayersPageViewModel : BaseViewModel
    {
        public List<Player> Players { get; set; }

        public Command DeletePlayerCommand { get; set; }
        public Command AddPlayerCommand { get; set; }

        public PlayersPageViewModel()
        {
            DeletePlayerCommand = new Command((o) => DeletePlayer(o));
            AddPlayerCommand = new Command(() => AddPlayer());
        }

        public async Task LoadAsync()
        {
            var players = await HttpHelper.Instance.GetListAsync<Player>("players");
            SetValue(() => Players, players);
        }

        private void DeletePlayer(object o)
        {
            var player = o as Player;
            if (player != null)
            {
                Debug.WriteLine($"Delete Player: {player.Name}");
            }
            else
            {
                throw new Exception("Player is null");
            }
        }

        private void AddPlayer()
        {
            Debug.WriteLine("Add Player");
        }
    }
}
